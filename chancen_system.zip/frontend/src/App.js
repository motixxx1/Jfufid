import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

const socket = io('http://localhost:3000'); // Replace with your server URL

const App = () => {
  const [user, setUser] = useState({ credits: 0 });
  const [recommendation, setRecommendation] = useState('');

  useEffect(() => {
    // Get user data from backend
    axios.get('/api/user/1')
      .then(response => {
        setUser(response.data);
      });

    // Listen for real-time updates from server
    socket.on('recommendation', (data) => {
      setRecommendation(data);
    });
  }, []);

  const handleGetRecommendation = () => {
    socket.emit('getRecommendation', { type: 'game' });
  };

  return (
    <div>
      <h1>Chancen System</h1>
      <p>Credits: {user.credits}</p>
      <button onClick={handleGetRecommendation}>Get Recommendation</button>
      {recommendation && <p>Recommendation: {recommendation}</p>}
    </div>
  );
};

export default App;
