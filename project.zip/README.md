# Project Instructions

This is a simple Flask application that manages user credits using an SQLite database.

## Setup Instructions:

1. Install Python 3.x if you haven't already.
2. Install Flask:
   ```bash
   pip install Flask
   ```
3. Set up the database:
   - Download the `db_setup.sql` file.
   - Run the SQL file using an SQLite client to create the `users.db` database and tables.
4. Start the Flask application:
   ```bash
   python app.py
   ```
5. Access the app in your browser:
   - Open `http://127.0.0.1:5000/credits/user1` to get credits for 'user1'.
