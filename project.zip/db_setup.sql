CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    credits INTEGER
);

INSERT INTO users (username, credits) VALUES ('user1', 100);
INSERT INTO users (username, credits) VALUES ('user2', 50);
