from flask import Flask, jsonify
import sqlite3

app = Flask(__name__)

@app.route('/credits/<username>', methods=['GET'])
def get_credits(username):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("SELECT credits FROM users WHERE username=?", (username,))
    result = cursor.fetchone()
    conn.close()
    
    if result:
        return jsonify({'credits': result[0]})
    return jsonify({'error': 'User not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
